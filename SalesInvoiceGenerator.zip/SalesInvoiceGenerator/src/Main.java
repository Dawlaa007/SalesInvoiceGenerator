import controller.FileOperations;
import view.view;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        view dis = new view();
        FileOperations f = new FileOperations();
        f.readFileInvoiceHeader();
        f.readFileInvoiceLine();
        dis.dismain();
        int choice = sc.nextInt();
        if (choice == 1) {
            f.AddInvoiceHeader();
            f.WriteFileInvoiceHeader();
            f.WriteFileInvoiceLine();
        } else if (choice == 2) {
            dis.display(f.getInvoiceHeader());
        }

    }
}