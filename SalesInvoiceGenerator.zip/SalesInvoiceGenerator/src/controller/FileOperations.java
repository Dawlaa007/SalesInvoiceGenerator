package controller;


import com.opencsv.CSVWriter;
import model.InvoiceHeader;
import model.InvoiceLine;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class FileOperations {
    InvoiceLine receipt = new InvoiceLine();
    private ArrayList<InvoiceHeader> invoiceHeader = new ArrayList<>();
    private ArrayList<InvoiceLine> invoiceLine = new ArrayList<>();

    public void readFileInvoiceHeader() {
        //read file
        try {
            Scanner sc = new Scanner(new File("src/controller/InvoiceHeader.csv"));

            //setting comma as delimiter pattern
            //sc.useDelimiter(",");
            while (sc.hasNext()) {

                InvoiceHeader user = new InvoiceHeader();
                String name = " ", date = " ", num = " ";
                num = (String) sc.next();
                String[] line = num.split(",", 3);
                user.setInvoiceNum(line[0]);
                user.setInvoiceDate(line[1]);
                user.setCustomerName(line[2]);

                invoiceHeader.add(user);
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.print("file not found  try");

        }


    }

    public void readFileInvoiceLine() {
        //read file

        try {
            Scanner sc = new Scanner(new File("src/controller/InvoiceLine.csv"));


            //setting comma as delimiter pattern
            // count to move between element in invoiceHeader

            while (sc.hasNext()) {
                InvoiceLine receipt = new InvoiceLine();

                String line1 = sc.next();
                String[] line = line1.split(",", 4);

                receipt.setInvoiceNum(line[0]);
                receipt.setItemName(line[1]);
                receipt.setItemPrice(line[2]);
                receipt.setCount(line[3]);

                invoiceLine.add(receipt);

            }

            //closes the scanner
            sc.close();

            for (int i = 0; i < invoiceLine.size(); i++) {

                for (int j = 0; j < invoiceHeader.size(); j++) {

                    if (invoiceLine.get(i).getInvoiceNum().equals(invoiceHeader.get(j).getInvoiceNum())) {
                        invoiceHeader.get(j).AddItem(invoiceLine.get(i));
                        break;
                    }
                }

            }
        } catch (FileNotFoundException e) {
            System.out.print("file not found");
            ;
        }

    }


    public void WriteFileInvoiceHeader() {


        try {  File file = new File("src/controller/InvoiceHeader.csv");
            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file);

            // create CSVWriter object filewriter object as parameter
            CSVWriter writer = new CSVWriter(outputfile, ',',
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);

            for (int i = 0; i < invoiceHeader.size(); i++) {
                // add data to csv
                String[] data1 = {invoiceHeader.get(i).getInvoiceNum(),
                        invoiceHeader.get(i).getInvoiceDate(),
                        invoiceHeader.get(i).getCustomerName()};
                writer.writeNext(data1);

            }
            // closing writer connection
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void WriteFileInvoiceLine() {
        try {
            File file = new File("src/controller/InvoiceLine.csv");

            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file);

            // create CSVWriter object filewriter object as parameter
            CSVWriter writer = new CSVWriter(outputfile, ',',
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.DEFAULT_LINE_END);

            for (int i = 0; i < invoiceHeader.size(); i++) {
                // add data to csv
                for (int j = 0; j < invoiceHeader.get(i).getInvoiceLine().size(); j++) {
                    String[] data1 = {invoiceHeader.get(i).getInvoiceLine().get(j).getInvoiceNum(),
                            invoiceHeader.get(i).getInvoiceLine().get(j).getItemName(),
                            invoiceHeader.get(i).getInvoiceLine().get(j).getItemPrice(),
                            invoiceHeader.get(i).getInvoiceLine().get(j).getCount(),
                    };
                    writer.writeNext(data1);
                }
            }
            // closing writer connection
            writer.close();
        } catch (IOException e) {
            System.out.print("file not found can not write the data");
            e.printStackTrace();
        }

    }

    public ArrayList<InvoiceHeader> getInvoiceHeader() {
        return invoiceHeader;
    }

    public void setInvoiceHeader(ArrayList<InvoiceHeader> invoiceHeader) {
        this.invoiceHeader = invoiceHeader;
    }

    public ArrayList<InvoiceLine> getInvoiceLine() {
        return invoiceLine;
    }

    public void setInvoiceLine(ArrayList<InvoiceLine> invoiceLine) {
        this.invoiceLine = invoiceLine;
    }

    public void AddInvoiceHeader() {
        try {


        Scanner sc = new Scanner(System.in);
        InvoiceHeader user = new InvoiceHeader();
        System.out.println("enter   InvoiceNum ");
        user.setInvoiceNum(sc.next());
        System.out.println("enter   InvoiceDate ");
        user.setInvoiceDate(sc.next());
        System.out.println("enter   CustomerName ");
        user.setCustomerName(sc.next());
        System.out.println("add   Items   ");
        do {
            InvoiceLine receipt = new InvoiceLine();
            System.out.println("enter   InvoiceNum ");
            receipt.setInvoiceNum(sc.next());
            System.out.println("enter   ItemName ");
            receipt.setItemName(sc.next());
            System.out.println("enter   ItemPrice ");
            receipt.setItemPrice(sc.next());
            System.out.println("enter   ItemCount ");
            receipt.setCount(sc.next());
            user.AddItem(receipt);
            System.out.println("enter   0  if  u Dont  want add item   ");
        } while (sc.next().equals('0'));
        invoiceHeader.add(user);
        }catch (Exception e){
            System.out.println("error in enter the data ");
        }
    }


}
