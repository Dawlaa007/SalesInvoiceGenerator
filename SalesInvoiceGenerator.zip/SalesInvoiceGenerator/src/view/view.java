package view;

import model.InvoiceHeader;

import java.util.ArrayList;

public class view {

    public void dismain() {

        System.out.println(" chose 1 for add or 2 for display ");

    }

    public void display(ArrayList<InvoiceHeader> invoiceHeader) {
        for (int i = 0; i < invoiceHeader.size(); i++) {

            System.out.println(invoiceHeader.get(i).getInvoiceNum());
            System.out.println("{");
            System.out.println("Invoice" + i + "Date (" + invoiceHeader.get(i).getInvoiceDate() + ")   " + invoiceHeader.get(i).getCustomerName());
            for (int j = 0; j < invoiceHeader.get(i).getInvoiceLine().size(); j++) {
                System.out.println(invoiceHeader.get(i).getInvoiceLine().get(j).getItemName() + "  " + invoiceHeader.get(i).getInvoiceLine().get(j).getItemPrice() + "  " + invoiceHeader.get(i).getInvoiceLine().get(j).getCount());

            }
            System.out.println("}");
        }
    }

}
