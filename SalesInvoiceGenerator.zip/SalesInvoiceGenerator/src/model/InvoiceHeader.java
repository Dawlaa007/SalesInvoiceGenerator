package model;

import java.util.ArrayList;

public class InvoiceHeader {
    ArrayList<InvoiceLine> InvoiceLine = new ArrayList<>();
    private String invoiceNum;
    private String invoiceDate;
    private String customerName;

    public String getInvoiceNum() {
        return invoiceNum;
    }

    public void setInvoiceNum(String invoiceNum) {
        this.invoiceNum = invoiceNum;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public ArrayList<model.InvoiceLine> getInvoiceLine() {
        return InvoiceLine;
    }

    public void setInvoiceLine(ArrayList<model.InvoiceLine> invoiceLine) {
        InvoiceLine = invoiceLine;
    }

    public void AddItem(InvoiceLine receipt) {
        InvoiceLine.add(receipt);

    }
}
