package model;

public class InvoiceLine {

    private String InvoiceNum;
    private String ItemName;
    private String ItemPrice;
    private String Count;

    public InvoiceLine() {
    }

    public InvoiceLine(String itemName, String itemPrice, String count) {
        ItemName = itemName;
        ItemPrice = itemPrice;
        Count = count;
    }

    public String getInvoiceNum() {
        return InvoiceNum;
    }

    public void setInvoiceNum(String invoiceNum) {
        InvoiceNum = invoiceNum;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String itemName) {
        ItemName = itemName;
    }

    public String getCount() {
        return Count;
    }

    public void setCount(String count) {
        Count = count;
    }

    public String getItemPrice() {
        return ItemPrice;
    }

    public void setItemPrice(String itemPrice) {
        ItemPrice = itemPrice;
    }
}
